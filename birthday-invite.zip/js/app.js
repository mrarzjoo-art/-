/* =========================================================
   دعوت‌نامه جشن — منطق برنامه
   ========================================================= */

(function () {
  "use strict";

  var STORAGE_KEY = "party-invite-guest";

  var loginView = document.getElementById("login-view");
  var inviteView = document.getElementById("invite-view");
  var loginForm = document.getElementById("login-form");
  var phoneInput = document.getElementById("phone");
  var passwordInput = document.getElementById("password");
  var loginError = document.getElementById("login-error");

  var countdownTimer = null;

  // ---------- کمکی: تبدیل ارقام فارسی/عربی به انگلیسی و حذف فاصله‌ها ----------
  function normalizeDigits(value) {
    if (!value) return "";
    var persian = "۰۱۲۳۴۵۶۷۸۹";
    var arabic = "٠١٢٣٤٥٦٧٨٩";
    var out = "";
    for (var i = 0; i < value.length; i++) {
      var ch = value[i];
      var pIndex = persian.indexOf(ch);
      var aIndex = arabic.indexOf(ch);
      if (pIndex > -1) out += pIndex;
      else if (aIndex > -1) out += aIndex;
      else out += ch;
    }
    return out.replace(/[\s\-]/g, "");
  }

  function findGuest(phoneRaw, passwordRaw) {
    var phone = normalizeDigits(phoneRaw);
    var password = normalizeDigits(passwordRaw);
    for (var i = 0; i < GUESTS.length; i++) {
      var g = GUESTS[i];
      if (normalizeDigits(g.phone) === phone && normalizeDigits(g.password) === password) {
        return g;
      }
    }
    return null;
  }

  // ---------- ورود ----------
  loginForm.addEventListener("submit", function (e) {
    e.preventDefault();
    loginError.hidden = true;

    var guest = findGuest(phoneInput.value, passwordInput.value);
    if (!guest) {
      loginError.textContent = "شماره موبایل یا رمز عبور درست نیست.";
      loginError.hidden = false;
      return;
    }

    sessionStorage.setItem(STORAGE_KEY, guest.name);
    revealInvite(guest.name);
  });

  document.getElementById("logout-btn").addEventListener("click", function () {
    sessionStorage.removeItem(STORAGE_KEY);
    if (countdownTimer) clearInterval(countdownTimer);
    inviteView.hidden = true;
    loginView.hidden = false;
    loginForm.reset();
    phoneInput.focus();
  });

  // ---------- نمایش دعوت‌نامه ----------
  function revealInvite(guestName) {
    document.getElementById("invite-eyebrow").textContent = PARTY.eventTitle;
    document.getElementById("invite-heading").textContent = guestName + " عزیز";
    document.getElementById("party-date").textContent = PARTY.dateDisplay;
    document.getElementById("party-time").textContent = PARTY.timeDisplay;
    document.getElementById("party-address").textContent = PARTY.address;

    var mapFrame = document.getElementById("map-frame");
    mapFrame.src = "https://www.google.com/maps?q=" + encodeURIComponent(PARTY.mapQuery) + "&output=embed";

    loginView.hidden = true;
    inviteView.hidden = false;

    startCountdown();
  }

  // ---------- شمارش معکوس ----------
  function startCountdown() {
    var target = new Date(PARTY.startISO).getTime();
    var elEls = {
      days: document.getElementById("cd-days"),
      hours: document.getElementById("cd-hours"),
      minutes: document.getElementById("cd-minutes"),
      seconds: document.getElementById("cd-seconds"),
    };
    var countdownBox = document.getElementById("countdown");
    var startedMsg = document.getElementById("countdown-started");

    function pad(n) { return String(n).padStart(2, "0"); }

    function tick() {
      var diff = target - Date.now();
      if (diff <= 0) {
        if (countdownTimer) clearInterval(countdownTimer);
        countdownBox.hidden = true;
        startedMsg.hidden = false;
        return;
      }
      countdownBox.hidden = false;
      startedMsg.hidden = true;

      var totalSeconds = Math.floor(diff / 1000);
      var days = Math.floor(totalSeconds / 86400);
      var hours = Math.floor((totalSeconds % 86400) / 3600);
      var minutes = Math.floor((totalSeconds % 3600) / 60);
      var seconds = totalSeconds % 60;

      elEls.days.textContent = pad(days);
      elEls.hours.textContent = pad(hours);
      elEls.minutes.textContent = pad(minutes);
      elEls.seconds.textContent = pad(seconds);
    }

    tick();
    if (countdownTimer) clearInterval(countdownTimer);
    countdownTimer = setInterval(tick, 1000);
  }

  // ---------- افزودن به تقویم (فایل ics) ----------
  function toICSDate(isoString) {
    var d = new Date(isoString);
    return d.getUTCFullYear() +
      String(d.getUTCMonth() + 1).padStart(2, "0") +
      String(d.getUTCDate()).padStart(2, "0") + "T" +
      String(d.getUTCHours()).padStart(2, "0") +
      String(d.getUTCMinutes()).padStart(2, "0") +
      String(d.getUTCSeconds()).padStart(2, "0") + "Z";
  }

  document.getElementById("add-calendar-btn").addEventListener("click", function () {
    var ics = [
      "BEGIN:VCALENDAR",
      "VERSION:2.0",
      "PRODID:-//party-invite//FA",
      "CALSCALE:GREGORIAN",
      "BEGIN:VEVENT",
      "UID:" + Date.now() + "@party-invite",
      "DTSTAMP:" + toICSDate(new Date().toISOString()),
      "DTSTART:" + toICSDate(PARTY.startISO),
      "DTEND:" + toICSDate(PARTY.endISO),
      "SUMMARY:" + PARTY.eventTitle,
      "LOCATION:" + PARTY.address,
      "DESCRIPTION:" + PARTY.timeDisplay,
      "END:VEVENT",
      "END:VCALENDAR",
    ].join("\r\n");

    var blob = new Blob([ics], { type: "text/calendar;charset=utf-8" });
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url;
    a.download = "invitation.ics";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 2000);
  });

  // ---------- بازیابی نشست فعال ----------
  var savedGuestName = sessionStorage.getItem(STORAGE_KEY);
  if (savedGuestName) {
    revealInvite(savedGuestName);
  }
})();
